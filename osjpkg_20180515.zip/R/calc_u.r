#' calcuate u-value
#' 
#' This function is to get u-value for scanning ks-test
#' For more information, please visit http://tongtongsear.tistory.com/227
#' @param mm (default=mat) : Input matrix, 1st row drug response, 2nd mutation
#' @keywords ks-test
#' @export
#' @examples
#' u_val=calc_u(mm='your_matrix') # Get real u value
#' scanning_ks_test(u_real=u_val,iter=500)

  #-----------------------------------------
  # Calculate U score
  #-----------------------------------------
    calc_u=function(mm=mat){ # mat 2xn_samples, 1st='drug response', 2nd='mutation'
      # Sort the matrix according drug response
      mm=mm[,order(mm[1,],decreasing = F)]
      # Calc the u
      t_val=rowSums(mm[2,])
      n_sam=ncol(mm)
      j_wh=which(mm[2,]==1) # V(j)
      j=1:t_val # J vectors
      u_max=(j/t_val)-(j_wh/n_sam)
      return(max(u_max))
    }