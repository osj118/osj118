#' Table expanding function
#'
#' This function is to draw oncoprint for mutation and CNV which is displayed in Cancer Types Summary of cbioportal
#' GBM_study=gbm_tcga_pub2013, Genetic_profile=gbm_tcga_pub2013_gistic & gbm_tcga_pub2013_mutations
#' @param gene (default='EGFR') : Official genesymbol that can be recognized by cBioPortal
#' @param color (default=c('Multiple'='dimgrey','CNV_del'='blue','CNV_amp'='firebrick1','Mutation'='darkgreen')) : Color for oncoprint, do not change the order of category
#' @keywords oncoprint, cbioportal
#' @export
#' @examples
#' gbm_mut_cnv_oncoprint(gene='EGFR',color=c('Multiple'='dimgrey','CNV_del'='blue','CNV_amp'='firebrick1','Mutation'='darkgreen'))
# oncoprint function
gbm_mut_cnv_oncoprint=function (gene = NA, color = c(Multiple = "dimgrey", CNV_del = "blue", 
                               CNV_amp = "firebrick1", Mutation = "darkgreen")){
  if (any(c("gbm_study_oncoprint_study", "case_list_oncoprint", 
            "genetic_info_oncoprint") %in% ls() == F)) {
    oncoprint_cbioportal <<- CGDS("http://www.cbioportal.org/public-portal/")
    tmp = getCancerStudies(oncoprint_cbioportal)
    rownames(tmp)=tmp[,1]
    gbm_study_oncoprint_study <<- tmp['gbm_tcga_pub2013', 1]
    case_list = getCaseLists(oncoprint_cbioportal, gbm_study_oncoprint_study)
    case_list_oncoprint <<- case_list[3, 1]
    geneticprofile = getGeneticProfiles(oncoprint_cbioportal, 
                                        gbm_study_oncoprint_study)
    genetic_info_oncoprint <<- geneticprofile[c(3, 7), ]
  }
  gbm_cnv_mut_tcga = getProfileData(oncoprint_cbioportal, gene, 
                                    genetic_info_oncoprint[, 1], case_list_oncoprint)
  gbm_cnv_mut_tcga = apply(gbm_cnv_mut_tcga, 2, as.character)
  gbm_cnv_mut_tcga[gbm_cnv_mut_tcga[, 1] == "NaN", 1] = NA
  gbm_cnv_mut_tcga2 = as.data.frame(gbm_cnv_mut_tcga[!is.na(gbm_cnv_mut_tcga[, 
                                                                             1]), ], stringsAsFactors = F)
  gbm_cnv_mut_tcga2[, 1] = as.numeric(gsub(gbm_cnv_mut_tcga2[, 
                                                             1], pattern = " ", replacement = ""))
  cnv_amp = length(which(gbm_cnv_mut_tcga2[, 1] > 1 & is.na(gbm_cnv_mut_tcga2[, 
                                                                              2])))/nrow(gbm_cnv_mut_tcga2) * 100
  cnv_del = length(which(gbm_cnv_mut_tcga2[, 1] < (-1) & is.na(gbm_cnv_mut_tcga2[, 
                                                                                 2])))/nrow(gbm_cnv_mut_tcga2) * 100
  int_s = length(which(abs(gbm_cnv_mut_tcga2[, 1]) > 1 & !is.na(gbm_cnv_mut_tcga2[, 
                                                                                  2])))/nrow(gbm_cnv_mut_tcga2) * 100
  mut_s = length(which(abs(gbm_cnv_mut_tcga2[, 1]) != 2 & !is.na(gbm_cnv_mut_tcga2[, 
                                                                                   2])))/nrow(gbm_cnv_mut_tcga2) * 100
  mat = rbind(int_s, cnv_del, cnv_amp, mut_s)
  rownames(mat) = c("Multiple alteration", "Deep deletion", 
                    "Amplification", "Mutation")
  rownames(mat) = paste0(rownames(mat), " (", round(mat[, 1], 
                                                    digits = 2), "%)")
  wh = which(mat[, 1] != 0)
  barplot(as.matrix(mat[wh, ]), col = color[wh], legend = T, 
          beside = F, ylab = "Frequency(%)", names.arg = gene)
}