#' Convert FPKM values into TPM value
#' 
#' This function is to convert gene expression FPKM value into TPM value.
#' The formula is FPKM/sum(FPKM)*10^6=TPM
#' Converting TPM to FPKM is impossible mathmatically unless sum(FPKM) is available.
#' Proof is http://tongtongsear.tistory.com/235
#' @param mm (default=NA) : Input expression matrix. rows are genes and columns are samples
#' @keywords TPM, FPKM, Conversion
#' @export
#' @examples
#' (mat=matrix(rnorm(100,mean=10),nrow=20,ncol=5,dimnames=list(paste0('gene',LETTERS[1:20]),paste0('sample',LETTERS[1:5]))))
#' Convert_FPKM2TPM(mat)
Convert_FPKM2TPM=function(mm=NA){
      res=t(aaply(mm,.margins = 2,.progress = 'text',function(x){
        y=x/sum(x)*10^6
        return(y)
      }))
      return(res)
}

