#' Grep function for multiple characters
#'
#' This function is to use grep with vector
#' @param input (default=NULL) : Input character vector
#' @param pattern (default=NULL) : Character patterns
#' @param ignore.case (default=T) : Whether ignore difference between capital and small letter
#' @param fixed (default=F) : Same with grep function (see ?grep)
#' @keywords table
#' @export
#' @examples
#' multi_grep()

multi_grep=function(input=c(),pattern=c(),ignore.case=T,fixed=F){
  if(is.null(input)){
    print('input : input character vector')
    print('pattern : pattern list character vector')
    print('ignore.case (default T) : same with ignore.case')
    print('Output will be unique list of sites')
  }else{
    wh=c();for(j in 1:length(pattern)){
      wh=c(wh,grep(input,pattern = pattern[j],ignore.case = ignore.case,fixed = fixed))
    }
    wh=unique(wh)
    return(wh)
  }
}