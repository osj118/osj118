#' scanning ks test
#' 
#' This function is to get scanning ks-test p.value
#' For more information, please visit http://tongtongsear.tistory.com/227
#' @param mm (default=mat) : Input matrix, 1st row drug response, 2nd mutation
#' @param iter (default=5000) : Number of iteration
#' @keywords ks-test
#' @export
#' @examples
#' u_val=calc_u(mm='your_matrix') # Get real u value
#' scanning_ks_test(u_real=u_val,iter=500)

  #--------------------------------------
  # get p-value for U score
  #--------------------------------------
    scanning_ks_test=function(mm=mat,iter=5000,u_real,plot=F){
		# Count number of mut samples
			t_val=base::rowSums(mm[2,])
		# Caculate background
			back_rank=llply(1:iter,.fun=function(x){sort(sample(ncol(mm),t_val))}) # Random rank
			j=1:t_val;js=j/t_val;n_sam=ncol(mm) # Constants....
			u_bak=unlist(llply(back_rank,.fun=function(x){max(js-(x/n_sam))})) # Background u_scores
		# Drawing?
      p_val=length(which(u_bak>=u_real))/length(u_bak)
        if(plot){ # Drawing plot
        plot(density(u_bak),main=paste(collapse=" x ",rownames(mm)))
        mtext(side=3,adj = 1,text = paste0('u_real=',format(u_real,nsmall=4,digits=4),
                                           'p.val=',p_val))
        abline(v=u_real,col=2)}
      return(p_val)
    }