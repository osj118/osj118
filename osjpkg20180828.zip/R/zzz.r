#--------------------------
# .onLoad function
#--------------------------
.onAttach = function(libname,pkgname){
	packageStartupMessage('osjpkg attaching')
	source("http://bioconductor.org/biocLite.R")
}