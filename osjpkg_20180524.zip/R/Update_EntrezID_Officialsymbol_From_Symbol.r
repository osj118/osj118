#' Update_EntrezID_Officialsymbol_From_Symbol
#' 
#' This function is to get official symbol and entrezid using rentrez
#' For more information, please visit https://blog.naver.com/hyosil7979/220857307890
#' @param symbol (default=NULL) : symbol
#' @keywords genesymbol, entrez, official genesymbol, conversion
#' @export
#' @examples
#' Update_EntrezID_Officialsymbol_From_Symbol('P53')

Update_EntrezID_Officialsymbol_From_Symbol <-function(symbol){
  library(httr);library(curl);library(rentrez)
  #---- First: database[Gene], [TID]& [GENE]
  
  query1 <- paste("9606", "[TID] AND ", symbol, "[GENE]",sep="")

  res1 <- entrez_search(db="gene",  term=query1,retmax=1,version='2.0')

  cv1_1 <- tryCatch(entrez_summary(db="gene", id=res1$ids),error=function(e){return(NULL)})

  cv1_2 <- as.vector(unlist(tryCatch(extract_from_esummary(cv1_1, c("name","uid")),error=function(e){return(NULL)})))

  if(!is.null(cv1_2)& length(cv1_2)==2){
    
    mt1 <-c(symbol,cv1_2)
    
    return(mt1);
    
  }

  #---- Second: database[Gene], [TID]& [ALL]
  
  if(is.null(cv1_2)){
    
    query2 <- paste("9606", "[TID] AND ", symbol, "[ALL]",sep="")
    
    res2 <- entrez_search(db="gene",  term=query2,retmax=1)
    
    cv2_1 <- entrez_summary(db="gene", id=res2$ids)
    
    cv2_2 <- as.vector(unlist(extract_from_esummary(cv2_1, c("name","uid"))))
    
    if(!is.null(cv2_2)& length(cv2_2)==2){
      
      mt2 <-c(symbol,cv2_2)
      
      return(mt2);
      
    }
    
    #---- Third: database[Gene], [TID] & [ALL]
    
    if(is.null(cv2_2)){
      
      unigene.query <- paste("9606", "[TXID] AND ", symbol , "[ALL]",sep="")
      
      unigene.res2 <- entrez_search(db="unigene",  term=unigene.query,retmax=1)
      
      unigene.1 <- entrez_summary(db="unigene", id=unigene.res2$ids )
      
      unigene.2 <- as.vector(unlist(extract_from_esummary(unigene.1, c("gene"))))
      
      
      
      query3 <- paste("9606", "[TID] AND ", unigene.2, "[GENE]",sep="")
      
      res3 <- entrez_search(db="gene",  term=query3,retmax=1)
      
      cv3_1 <- entrez_summary(db="gene", id=res3$ids)
      
      cv3_2 <- as.vector(unlist(extract_from_esummary(cv3_1, c("name","uid"))))
      
      if(!is.null(cv3_2) & length(cv3_2)==2){
        
        mt3 <-c(symbol,cv3_2)
        
        return(mt3);
        
      }
    }
  }
}
# https://blog.naver.com/hyosil7979/220857307890