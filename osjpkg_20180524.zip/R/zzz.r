#--------------------------
# .onLoad function
#--------------------------
.onAttach = function(libname,pkgname){
	packageStartupMessage('osjpkg attaching')
	source("http://bioconductor.org/biocLite.R")
  # Install packages from CranR
  necessary_pkg=c('dplyr','plyr','tidyr','glmnet','drc','limma','rentrez','matrixStats','data.table','xlsx',
                  'pheatmap','devtools','cgdsr','doParallel','foreach','circlize','gplots','rjson','RCurl',
                  'xlsx','gplots','pheatmap','stringi','Rcpp','blob','bit','bindr','broom','ggpubr','cmprsk',
				  'survMisc','rio','Matrix')
  lib_load=function(pkg_s=necessary_pkg){
    installed_pkg=rownames(installed.packages())
    uninstalled_pkg=setdiff(pkg_s,installed_pkg)
    if(length(uninstalled_pkg)>0){
      install.packages(uninstalled_pkg)
    }
    sapply(pkg_s,function(x){require(x,character.only = T,quietly = T)})
  }
  lib_load()
  # Intsall packages from bioconductor
  bio_libs=c('biomaRt','org.Hs.eg.db','TCGAbiolinks','UniProt.ws','GSVA')
  bio_lib_load=function(pkg_s=bio_libs){
    installed_pkg=rownames(installed.packages())
    uninstalled_pkg=setdiff(pkg_s,installed_pkg)
    if(length(uninstalled_pkg)>0){
      biocLite(pkgs = uninstalled_pkg)
    }
    sapply(pkg_s,function(x){require(x,character.only = T,quietly = T)})
  }
  bio_lib_load()
}