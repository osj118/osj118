#' Table expanding function
#'
#' This function is to expand number of row matrix or data.frame by a specific key column in the table.
#' @param key_colnames (default=NA) : Column name of matrix containing key values to expand table.
#' @param mat (default=NA) : Matrix to be expanded.
#' @param sep (defaule=';') : Character separater to separate text in the field (ex. TP53;EGFR -> [1]TP53 [2]EGFR)
#' @keywords table
#' @export
#' @examples
#' table_expand()
# Table expanding function
table_expand=function(key_colnames=NA,mat=matrix(),sep=';'){
	if(is.na(key_colnames)){
		cat('key_colnames : column name of matrix to expand the table\n')
		cat('mat : matrix\n')
		cat('sep : separator character will separate the values\n')
		cat('ex. ERBB1;EGFR->ERBB1, EGFR-> 2 rows matrix')
		break()
	}else{
	# Take rows having separator value
	wh=which(colnames(mat)==key_colnames)
	gr=grep(mat[,wh],pattern=sep)
	tmp=mat[gr,];final_mat=c()
	for(i in 1:nrow(tmp)){
		gens=unlist(strsplit(tmp[i,wh],sep));tm2=c()
		for(j in 1:length(gens)){
		tm2=rbind(tm2,tmp[i,])
		};tm2[,wh]=gens
		final_mat=rbind(final_mat,tm2)
	}
	ma2=rbind(mat[-gr,],final_mat)
	return(ma2)
	}
}