#--------------------------
# .onLoad function
#--------------------------
.onAttach = function(libname,pkgname){
	packageStartupMessage('osjpkg attaching')
	source("https://bioconductor.org/biocLite.R")
}