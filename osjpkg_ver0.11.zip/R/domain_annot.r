#' Protein domain annotation crawling
#'
#' This function is to retrieve the protein domain annotation by web crawling\nInstall 'biomaRt', 'rjson', 'RCurl', 'plyr'
#' @param ids (default='PF13900') : Input character vector for pfam_id or uniprot_id
#' @param mat (default='pfam') : Idtype, recomment to use pfam id
#' @keywords table
#' @export
#' @examples
#' domain_annot()

domain_annot=function(ids='PF13900',idtype='pfam'){
  if(is.null(ids)){
    print('ids : input character vector for pfam_id or uniprot_id')
	print('idtype : pfam(default) or uniprot')
    print('use biomart to get pfam id and uniprot id')
    print('try bellow')
    cat("ensembl=useMart(biomart='ensembl',dataset = 'hsapiens_gene_ensembl')\n")
    cat("tmp=getBM(attributes = c('hgnc_symbol','ensembl_peptide_id','pfam','pfam_start','pfam_end'),
          filters= 'ensembl_peptide_id',values='ENSP00000428056',mart=ensembl)")
  }else{
    library('rjson');library('RCurl');library(plyr)
    ids=ids
		if(length(idtype)>1){warning('Provide unique id (pfam or uniprot)');break}
		if(idtype=='pfam'){
			print('pfam initiating')
				id2=unlist(llply(ids,.progress='text',function(x){
				  #x=ids
					cat('\r',x)
					url=getURL(paste0('http://pfam.xfam.org/family/',x))
					info=unlist(strsplit(url,"\""))
					info=info[grep(info,pattern = 'Summary:')]
					if(length(info)!=0){
  					info=unlist(strsplit(info,": ",fixed = T))[2]
  					info=unlist(strsplit(info,"<",fixed = T))[1]}else{info='Not_available'}
					}))
					print('Conversion done')
						if(length(id2)==length(ids)){
						  names(id2)=ids
    						} #else{warning('Some of pfam ids have no appropriate ids\nConversion failed')}
		}
					
		if(idtype=='uniprot'){
			print('Uniprot domain information consists of position and names')
				id2=ldply(ids,.progress='text',function(x){
					cat('\r',x)
					url=readLines(paste0('http://www.uniprot.org/uniprot/',x))
					info=url[grep(url,pattern = 'key=Domain',fixed = F)]
					info=unlist(strsplit(info,split="=",perl = T))
					# Location
						inf2=info[grep(info,pattern = x)]
						inf2=unlist(lapply(inf2,function(k){unlist(strsplit(k,"&"))[1]})) 
						inf2=gsub(inf2,pattern = x,replacement = "")
						inf2=gsub(inf2,pattern = ']',replacement = "")
						inf2=gsub(inf2,pattern = "[",replacement = "",fixed = T)
					# names
						inf3=info[grep(info,pattern = "</span><span class")]
						inf3=unlist(lapply(inf3,function(k){unlist(strsplit(k,">"))[2]}))
						inf3=unlist(lapply(inf3,function(k){unlist(strsplit(k,"<"))[1]}))
					
					res=cbind(rep(x,length(inf2)),inf2,inf3)
					colnames(res)=c('uniprotID','Position_in_protein','Domain_names')
					mat=res
				})
		}
      }
    return(id2)
  }