#' Get_official_symbol
#'
#' This function is slightly modified function from alias2Symbols[limma]
#' @param genes (default=NULL) : Gene symbols including alias
#' @param species (default=NULL) : See ?alias2Symbols
#' @keywords official_symbols
#' @export
#' @examples
#' gene=c('TP53',paste0('gene',1:1000),'EGFR','PTEN','PUMA')
#' output_symbols=get_official_symbol(genes=gene)

get_official_symbol=function(genes,species='Hs'){
  # Convert a set of alias names to official gene symbols
  # via Entrez Gene identifiers
  # alias -> Entrez gene -> official gene symbol
  # Slightly modified limma's alias2symbol
  alias <- as.character(genes)
  species <- match.arg(species,c("Dm","Hs","Mm","Rn"))
  DB <- paste("org",species,"eg","db",sep=".")
  ALIAS2EG <- paste("org",species,"egALIAS2EG",sep=".")
  SYMBOL <- paste("org",species,"egSYMBOL",sep=".")
  suppressPackageStartupMessages(require("AnnotationDbi",character.only=TRUE))
  suppressPackageStartupMessages(require(DB,character.only=TRUE))
    # Separate official genesymbol from alias
    isSymbol <- alias %in% Rkeys(get(SYMBOL))
    alias2 <- alias[!isSymbol]
    off_sym=setdiff(alias[isSymbol],alias2);names(off_sym)=off_sym
    
    # Do Alias -> official symbol one by one
    library(plyr)
    tmp=unlist(plyr::llply(.data=alias2,.progress = 'text',
                    function(x){
                      cat('\r',x)
                      #cat(x)
                      tryCatch({eg <- mappedLkeys(get(ALIAS2EG)[x])
                               return(paste(collapse=";",as.character(mappedRkeys(get(SYMBOL)[eg]))))
                      }
                               ,
                               error=function(e){return(NA)})
                    }));names(tmp)=alias2
    # Export the results
    tm2=c(off_sym,tmp)
    tm3=cbind(names(tm2),tm2);colnames(tm3)=c('Input_symbols','Official_symbols')
    return(tm3)
  }
