#' ssGSEA with p.value
#' 
#' This function is to get ssGSEA ES score and its p.value (one-sided high).\cr
#' The p.value formulat is n(ES-score<=Random-ES-score)/n_of_permute\cr
#' The reason why I used 'equal or more(<=)' is to handle sparsity issue especially in single-cell RNAseq data.\cr
#' Its output is list of two table. One is ssGSEA score table and the other is p.value table.\cr
#' 
#' @param mm (default=NULL) : Input expression matrix. rows are genes and columns are samples
#' @param gene_sets_list (default=NULL) : List of genesets contatining genes.
#' @param iter_num (default=10^5) : Number of permutation to generate Random-ES-score and get empirical p-value
#' @param quick (default=F) : If TRUE, mean and standard deviation of random-ES-scores are calculated after 100 permutation.
#' @param alpha (default=0.25)numeric. Parameter for ssGSEA, the default is 0.25
#' @param scale (default=TRUE)logical. If True, normalize the scores by number of genes in the gene sets.
#' @param norm (default=FALSE)logical. If True, normalize the scores by the absolute difference between max and min values.
#' @param single (default=TRUE)logical. If True, use ssGSEA algorithm, otherwise use GSEA.
#' Then, virtual scores are generated using rnorm(n=iter_num,mean=mean(100xRANDOM-score),sd=sd(100XRANDOM-score)).
#' According to Wang et al(dx.doi.org/10.1016/j.ccell.2017.06.003), they found the resampling generated distribution could
#'  be replaced with Student-T distribution (sample size >30) or Normal distribution (sample size > 50) for getting very similar results.
#'  
#' @keywords ssGSEA, p.value, p-value
#' 
#' @export
#' @examples
#' (mat=matrix(rnorm(130,mean=10),nrow=26,ncol=5,dimnames=list(paste0('gene',LETTERS),paste0('sample',LETTERS[1:5]))))
#' (gene_sets_list=list(A_pathway=paste0('gene',sample(LETTERS,5)),B_pathway=paste0('gene',sample(LETTERS,15))))
#' system.time((ssGSEA_m1=ssGSEA_p(mm=mat,gene_sets=gene_sets_list,iter_num=10^5)))
#' system.time((ssGSEA_m2=ssGSEA_p(mm=mat,gene_sets=gene_sets_list,iter_num=10^5,quick=T))) # quick mode activated.
#' system.time((ssGSEA_m3=ssGSEA_p(mm=mat,gene_sets=gene_sets_list,iter_num=10^5)))
#' ssGSEA_m1;ssGSEA_m2;ssGSEA_m3
ssGSEA_p=function(mm=NULL,gene_sets=NULL,iter_num=10^5,quick=F, scale = T, norm = F, single = T,alpha=0.25){
  if(is.null(mm)){stop('Expression matrix is empty. Terminate process')}
  if(is.null(gene_sets)){stop('Gene_set_list is empty. Terminate process')}
  #------------------------------------
  # Getting Actual ES_Score calculation
  #------------------------------------
      es_score=ssgsea(mm=mm,gene_sets = gene_sets,alpha=alpha,scale=scale,norm=norm,single=single)
  #------------------------------------
  # Get empirical p.value
  #------------------------------------
      #------------
      # Quickmode
      #------------
        if(quick){ # if quick option activated
          message('quick mode is activated.')
          random_es=llply(1:100,function(x){
            mm2=mm[sample(1:nrow(mm),nrow(mm)),];rownames(mm2)=rownames(mm)
            rd_score=as.data.frame(ssgsea(mm=mm2,gene_sets = gene_sets,alpha=alpha,scale=scale,norm=norm,single=single),
                                   stringsAsFactors=F)
          })
          random_es2=do.call(rbind,random_es)
          # Get p.values one by one according to gene-set
            gene_set_names=names(gene_sets)
            gene_set_pval=ldply(gene_set_names,function(x){
              y=as.matrix(random_es2[grep(rownames(random_es2),pattern = x),])
              col_sd=matrixStats::colSds(y);col_mean=matrixStats::colMeans2(y)
              p.vals=c()
              for(i in 1:ncol(es_score)){
                rnd_scores=rnorm(iter_num,sd=col_sd,mean = col_mean) # Virtual scores are generated based on 100x permutation's mean and standDeviation.
                pval=length(which(rnd_scores>=es_score[grep(rownames(es_score),pattern = x),i]))
                p.vals=c(p.vals,pval/iter_num)
              };names(p.vals)=colnames(es_score)
              return(p.vals)
            });rownames(gene_set_pval)=rownames(es_score)
          # Export the result
          res=list('Actual_ES'=es_score,'Pvalue_quickmode'=gene_set_pval)
        }else{
      #---------------
      # Accurate mode
      #---------------
        message('quick mode is inactivated.')
        cl2=makeCluster(detectCores());registerDoParallel(cl2)
        random_es=llply(1:iter_num,.parallel=T,.paropts=list(.packages=c('osjpkg')), function(x){
          mm2=mm[sample(1:nrow(mm),nrow(mm)),];rownames(mm2)=rownames(mm)
          rd_score=as.data.frame(ssgsea(mm=mm2,gene_sets = gene_sets,alpha=alpha,scale=scale,norm=norm,single=single),
                                 stringsAsFactors=F)
        });stopCluster(cl2)
        random_es2=do.call(rbind,random_es)
        # Get p.values one by one according to gene-set
        gene_set_names=names(gene_sets)
        gene_set_pval=ldply(gene_set_names,function(x){
          y=as.matrix(random_es2[grep(rownames(random_es2),pattern = x),])
          p.vals=c()
          for(i in 1:ncol(es_score)){
            rnd_scores=y[,i]
            pval=length(which(rnd_scores>=es_score[grep(rownames(es_score),pattern = x),i]))
            p.vals=c(p.vals,pval/iter_num)
          };names(p.vals)=colnames(es_score)
          return(p.vals)
        });rownames(gene_set_pval)=rownames(es_score)
        # Export the result
        res=list('Actual_ES'=es_score,'Pvalue'=gene_set_pval)
        }
  return(res)
}