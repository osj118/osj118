#' survival analysis and get Log-rank p.value
#' 
#' This function is to get u-value for scanning ks-test
#' @param class (default=NULL,factor) : Input vector, 1st row drug response, 2nd mutation
#' @param survival_time (default=NULL,numeric) : Input vector, put them as numeric.
#' @param status (default=NULL,numeric) : Input vector, 0(alive) or 1(dead)
#' @param plot (default=T,logical) : True or False to draw the KM plot
#' @param colors (default=NULL,character) : Colors for each groups
#' @param xlab (default=NULL,character) : Put time scale (days, months, years....)
#' @param title (default=NULL,character) : Put title of plot
#' @param export (default=T,character) : True or False to export the results of survival analysis.
#' @keywords Log-rank test
#' @return
#' surv_formula : formula used in survfit and survdiff
#' survfit : survfit(surv_formula)
#' p.value : Log-rank p value survdiff(surv_formula)
#' @examples
#' cls=as.factor(paste0('GPC',rep(c(1,2,3),each=50)))
#' surv_time=c(rnorm(50,10),rnorm(50,100,sd=5),rnorm(50,50,sd=10))
#' status=sample(c(0,1),150,replace=T)
#' #Drawing only
#' survival_analysis(class=cls,survival_time=surv_time,status=status,plot=T,
#' colors=c('skyblue','tomato','darkgreen'),
#' xlab='Months',title='example',export=F)
#' #Result and plotting
#' survival_analysis(class=cls,survival_time=surv_time,status=status,plot=T,
#' colors=c('skyblue','tomato','darkgreen'),
#' xlab='Months',title='Result and plotting',export=T)
  #-----------------------------------------
  # draw plot
  #-----------------------------------------
    survival_analysis=function(class=NULL,survival_time=NULL,status=NULL,plot=T,colors=NULL,
                               xlab=NULL,title=NULL,export=T){
      frms=survival::Surv(survival_time,status)~class
      os=survival::survfit(frms)
      # Calculate Log-rank p.value
        pv=survival::survdiff(frms)
        pv=pchisq(pv$chisq,length(pv$n)-1,lower.tail = F)
      # Plotting?
        if(plot){
          plot(os,ylab='Survival probability',xlab=xlab,main=title,mark.time=T,cex=5,lwd=5,col=colors)
          mtext(paste0('Log-rank p=',format(pv,nsmall=3,digits=3,scientific=F)),adj=1,side=3)
          # Legend
            legend.txt=gsub(paste0(names(os$strata),'(N=',os$strata,')'),pattern='class=',replacement = "",fixed=T)
            legend('topright',legend = legend.txt,lwd=5,col=colors)
        }
      # Export result?
        if(export){return(list('surv_formula'=frms,'survfit'=os,'p.value'=pv))}
    }
    