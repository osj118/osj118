#' Drawing sig boxplot
#' 
#' This function is to draw boxplot with significant p.value code
#' ks.test, t.test and wilcox.test are available.
#' @param input_list (default=NULL) : Input list object with names.
#' @param test_method (default='t.test',character) : Test option parameter. You can also use ks.test and wilcox.test.
#' @param ns_visualize (default=FALSE) : Whether visualize nonsignificant notation should be drawn.
#' @param nsmall (default=1) : The minimum number of digits to the right of the decimal point. 0<=nsmall<=20
#' @param colors (default=NULL) : Boxplot color. Provide it as vector.
#' @param yaxis_lab (default=NULL) : Label of yaxis
#' @param title (default=NULL) : Title of the plot
#' @keywords ks-test, t-test, wilcox-test, boxplot
#' @export
#' @examples
#' input_list=list(a=rnorm(10,sd=10),b=rnorm(10,10),c=rnorm(20),d=rnorm(10,5,100))
#' # T-test
#' sig_boxplot(input_list=input_list,test_method='t.test',yaxis_lab='FPKM',ns_visualize=F)
#' sig_boxplot(input_list=input_list,test_method='t.test',yaxis_lab='FPKM',ns_visualize=T) # Nonsignificant will be plotted
#' # KS-test
#' sig_boxplot(input_list=input_list,test_method='ks.test',ns_visualize=T)
#' # Wilcox-test
#' sig_boxplot(input_list=input_list,test_method='wilcox.test',ns_visualize=T)
#' # Colors
#' sig_boxplot(input_list=input_list,test_method='wilcox.test',ns_visualize=T,colors=rainbow(4),title='Example',yaxis_lab='FPKM')
    sig_boxplot=function(input_list=NULL,test_method='t.test',ns_visualize=F,nsmall=1,yaxis_lab=NULL,colors=NULL,
                         title=NULL){
      if(is.null(input_list)){stop('Input data is empty. Terminate process')}
      # Test the categories in pairwise
        test_m=match.arg(test_method,choices = c('ks.test','t.test','wilcox.test'))
        test_n=length(input_list)-1
        test_res=c()
        for(i in 1:test_n){for(j in (i+1):length(input_list)){
          x=input_list[[i]];y=input_list[[j]]
          res=switch(test_m,
                 t.test=t.test(x,y)$p.value,
                 wilcox.test=wilcox.test(x,y)$p.value,
                 ks.test=ks.test(x,y)$p.value)
          res=format(res,nsmall=nsmall,digits=1,scientific=F)
          test_res=c(test_res,res)
          names(test_res)[length(test_res)]=paste0(names(input_list)[i],'_&&_',names(input_list)[j])
        }}
      # Remove non-sig pairs?
        if(!ns_visualize){test_res=test_res[test_res<0.05]}else{test_res[test_res>0.05]='NS'}  
      # Draw boxplot
        y_range=range(unlist(input_list));y_top=y_range[2]*(1+0.2*length(test_res))
        boxplot(input_list,ylab=yaxis_lab,col=colors,ylim=c(y_range[1],y_top),outline=F,ann=F,main=title,xaxt='n')
        axis(side=1,at=1:length(input_list),labels = F)
        # Draw jitterplot
          l_ply(1:length(input_list),function(x){
            stripchart(add=T,vertical = T,method = 'jitter',pch=19,at=x,input_list[[x]])
          })
        # Draw sigbar
          # Draw clamps for pairs
          label_y_gaps=seq(y_range[2]*1.04,y_top*0.96,length.out = length(test_res))
          test_label=unlist(strsplit(test_m,'.',fixed = T))
          test_label=paste(sep = "-",toupper(test_label[1]),test_label[2])
            for(i in 1:length(test_res)){
              fr_p=unlist(strsplit(names(test_res)[i],"_&&_"))
              to_p=which(names(input_list)==fr_p[2]);fr_p=which(names(input_list)==fr_p[1])
              segments(x0=fr_p,x1=to_p,y0=label_y_gaps[i],lwd = 3)
              if(test_res[i]!='NS'){
                text(x=(fr_p+to_p)/2,y=label_y_gaps[i],labels =paste0(test_label,' p=',test_res[i]),pos=3)
              }else{
                text(x=(fr_p+to_p)/2,y=label_y_gaps[i],labels = 'NS',pos=3)
              }
            }
        # ADD label
          y_min=min(y_range)
          y_min=ifelse(y_min>0,y_min*0.75,y_min*1.25)
          text(names(input_list),srt=-45,xpd=T,x=1:length(input_list),y=y_min,adj=0)
    }
    