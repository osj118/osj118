#' GCT file maker from gene expression data
#'
#' This function is to make and export GCT file format'
#' @param input (default=NA) : Expression data 1st column gene symbol. Remaining columns are gene expression of samples.
#' @param description (default=NA) : Character vector to describe information of genes. Its length should be same with nrow(input)
#' @param file_export (default=NA) : Filename to be exported. The file will be stored in current working directory.
#' If NA, the file won't be exported.
#' @keywords gct, ssGSEA
#' @export
#' @examples
#' mat=matrix(1:100,nrow=10,ncol=10);colnames(mat)=paste0('A',1:ncol(mat))
#' mat=cbind(paste0('gene',LETTERS[1:10]),mat);colnames(mat)[1]='symbol'
#' gct_maker(input=mat,description=letters[1:10])
gct_maker=function(input=NA,description=NA,file_export=NA){
  if(all(is.na(input))){stop('Process is terminated because input is NA')
    }else{
      input=as.matrix(input)
      # Get number of genes and samples
      n_sample=ncol(input)-1
      n_genes=nrow(input)
      # Make GCT matrix
      if(all(is.na(description))){x1=cbind(input[,1],input)}else{x1=cbind(input[,1],description,input[,-1])}
      colnames(x1)[1:2]=c('symbol','description')
      x1=rbind(colnames(x1),x1)
      # Convert gene expression matrix into vector
      gct_vec=apply(x1,1,function(y){paste(collapse = "\t",y)})
      # Attach the rest informations
      gct_vec=c('#1.2',paste0(n_genes,'\t',n_sample),gct_vec)
      # Export?
      if(is.na(file_export)){return(gct_vec)}else{
        write(file=file_export,x = gct_vec)
        print(paste0(file_export,' is stored in ',getwd()))
      }
    }
}