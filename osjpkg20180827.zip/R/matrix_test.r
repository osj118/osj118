#' Doing statistical test for two groups on matrix/data.frame
#' 
#' This function is to perform statistical test (ks.test, t.test, wilcox.test) on matrix.
#' This function requires p x n matrix where p represents gene/feature and n represents samples.
#' 
#' @param mm (default=NULL) : Input matrix (gene x sample). \cr
#' It is not necssary that the number of column is identical to the number of sample
#' @param groups (default=list) : List of two groups. Do not provide more than two groups.\cr
#' ex) list('GPC1'=c('sampleA','sampleB','sampleC'),'GPC2'=c('sampleX','sampleY','sampleZ'))
#' @param feature (default=NULL) : Name of feature in the matrix. (such as 'symbol','gene') \cr
#' If it is not provided, rownames will be used as name of feature
#' @param test_method (default='t.test') : test-method (ks.test, t.test, wilcox.test)\cr
#' The tests are two-sided.
#' @keywords ks-test, t-test, wilcox-test
#' @export
#' @examples
#' mat=as.data.frame(matrix(sample(c(rnorm(100,10),rnorm(100,20)),200),ncol=10))
#' colnames(mat)=LETTERS[1:10]
#' mat$symbol=paste0('Gene',LETTERS[1:20])
#' matrix_test(mm=mat,test_method='ks',groups=list('A_group'=LETTERS[1:5],'B_group'=LETTERS[6:10]),
#' feature='symbol')
matrix_test=function(mm=NULL,groups=NULL,feature=NULL,test_method='t.test'){
      if(is.null(mm)){warnings('Provide matrix');break}
      if(is.null(groups)){warnings('Provide group list');break}
      # Convert matrix into data.frame.matrix
        mm=as.data.frame.matrix(mm)
      # Do test
        # Select test-method
          test=match.arg(test_method,c('ks.test','t.test','wilcox.test'))
          message('Selected test method : ',test)
        # Do test
          res=ldply(1:nrow(mm),.progress = 'text',function(i){
            x1=as.numeric(mm[i,groups[[1]]]);x2=as.numeric(mm[i,groups[[2]]])
            pv=get(test)(x1,x2)$p.value
            c(pv,mean(x1),mean(x2))
          })
          colnames(res)=c(paste0(test,'_pvalue'),paste0(names(groups),'_mean'))
          if(is.null(feature)){res$feature=rownames(mm)}else{res$feature=mm[,feature]}
          res$fdr=p.adjust(res[,1],'fdr')
      # Order table
        res=res[,c('feature',paste0(test,'_pvalue'),'fdr',paste0(names(groups),'_mean'))]
        colnames(res)[3]=paste0(test,'_FDR')
      return(res)
}
