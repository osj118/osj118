#' Caculate simplicity score
#' 
#' This function is to calculate simplicity score which represent heterogenous subtype activation in a tumor.\cr
#' Simplicity score ranges from 0 to 1. Samples with high simplicity scores activated a single subtype.\cr
#' Lowest simplicity scores activated multiple subtypes.\cr
#' In case of simplicity score is negative value, that means at top activated signature's distance very close\cr
#'  and non-dominant is very non-significanct p-value.
#' \cr
#' Simplicity_score=[ADDS-ADNS]x(R[n-1]-R[0])/(N-1)
#' ADDS=sigma(i=1,N-1)[Ri-R0], ADNS(Accumulative distance between non-dominant subtypes)=sigma(j>i>0)[Rj-Ri]\cr
#' R0=minimum empirical p value(i.e The most dominant and significantly activated subtype.)\cr
#' Wang et al(dx.doi.org/10.1016/j.ccell.2017.06.003)
#' 
#' @param mm (default=NULL) : Input p.value matrix. Row is subtype and column is samples.
#' @param adjust (default=F) : In case of more than 4 subtypes, negative score can be calclated if two subtyps are
#' dominant and have simliar p.value and other subtypes are huge p-value or inter-distance between non-dominant subtypes
#' are large. To prevent negative score, simplicity score is\cr
#' Simplicity_score=(ADDS/(ADDS+ADNS))*(Max_p-Min_p)
#' @keywords simplicity score, subtype, heterogenous, subtype activation
#' @export
#' @examples
#' mat=matrix(rnorm(1000,mean=10),nrow=200,ncol=5,dimnames=list(paste0('gene',1:200),paste0('sample',LETTERS[1:5])))
#' gene_sets_list=list(subtype_A=paste0('gene',sample(1:200,50)),subtype_B=paste0('gene',sample(1:200,45)),
#' subtype_C=paste0('gene',sample(1:200,20)),subtype_D=paste0('gene',sample(1:200,100)))
#' ssGSEA_m2=ssGSEA_p(mm=mat,gene_sets_list=gene_sets_list,iter_num=10^5,quick=T) # quick mode activated.
#' subtype_p=ssGSEA_m2[[2]]
#' 
#' # Make sampleE has dominant subtype
#' subtype_p[4,5]=0.01;subtype_p[1:3,5]=c(0.99,0.96,0.97)
#' subtype_p[1:4,4]=c(0.01,0.02,0.52463,0.47904) # sampleD will have negative simplicity score
#' 
#' # Calculate simplicity_subtype_score
#' simplicity_subtype_score(mm=subtype_p)
#' simplicity_subtype_score(mm=subtype_p,adjust=T)
simplicity_subtype_score=function(mm=NULL,adjust=F){
  if(is.null(mm)){stop('Input matrix is empty. Terminate process')}
  if(nrow(mm)==1){stop('Simplicity score cannot be calculated when there is only single subtype. Terminate process')}
  mm=as.matrix(mm)
  #------------------------------------
  # Get simplicity score
  #------------------------------------
    # ADDS (Accumulative distance to the dominant subtype) scores
      adds=plyr::aaply(mm,.margins = 2,function(x){
        y=as.numeric(x) # Sort the p.values
        acc_dist=sum(y-min(y))
        return(acc_dist)
      })
    # ADNS (Accumulative distance between non-dominant subtype)
      adns=plyr::aaply(mm,.margins=2,function(x){
        y=sort(as.numeric(x))
        nums=c()
            for(i in 2:length(y)){for(j in i:length(y)){
              nums=c(nums,y[j]-y[i])
            }}
        adns_dist=sum(nums)
        return(adns_dist)
      })
    # Cacluate correction factor, (R[N-1]-R0)/(N-1), where N is number of subtype
      con_f=(matrixStats::colMaxs(mm)-matrixStats::colMins(mm))/(nrow(mm)-1)
      p_range=matrixStats::colMaxs(mm)-matrixStats::colMins(mm)
    # Calculate simplicity score
      simplicity_score=(adds-adns)*con_f
      simplicity_score2=(adds/(adds+adns))*p_range
      
    # Combine ADDS and ADNS
    if(adjust){
      ad_mat=rbind(adds,adns,con_f,p_range,simplicity_score,simplicity_score2)
      rownames(ad_mat)=c('ADDS','ADNS','Norm_factor','Pval_range','Simplicity_Score','Modified_Sim_score')
    }else{
      ad_mat=rbind(adds,adns,con_f,simplicity_score)
      rownames(ad_mat)=c('ADDS','ADNS','Norm_factor','Simplicity_Score')
    }
    return(ad_mat)
}
