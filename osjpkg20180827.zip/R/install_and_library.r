#' Install and attach libraries
#' 
#' This function is to install and attach predefined libraries.
#' @keywords library
#' @export
#' @examples
#' install_and_attach_lib()

  #-----------------------------------------
  # Calculate U score
  #-----------------------------------------
    install_and_attach_lib=function(){
      # Install packages from CranR
		necessary_pkg=c('plyr','tidyr','glmnet','drc','limma','rentrez','matrixStats','data.table','xlsx','mclust',
                  'pheatmap','devtools','doParallel','foreach','circlize','rjson','RCurl','haven','RSQLite','cgdsr',
                  'stringi','plotrix','pkgmaker','ClassDiscovery','caret','usethis','randomForest','e1071','dendextend')
	  lib_load=function(pkg_s=necessary_pkg){
		installed_pkg=rownames(installed.packages())
		uninstalled_pkg=setdiff(pkg_s,installed_pkg)
		if(length(uninstalled_pkg)>0){
		  sapply(uninstalled_pkg,function(x){install.packages(x,dependencies=c("Depends", "Imports", "LinkingTo"))})
		}
		sapply(pkg_s,function(x){require(x,character.only = T,quietly = T)})
	  }
		
	  # Intsall packages from bioconductor
		  bio_libs=c('biomaRt','org.Hs.eg.db','TCGAbiolinks','UniProt.ws','GSVA','maftools','ensembldb',
					"EnsDb.Hsapiens.v75",'DESeq')
		  bio_lib_load=function(pkg_s=bio_libs){
			installed_pkg=rownames(installed.packages())
			uninstalled_pkg=setdiff(pkg_s,installed_pkg)
			if(length(uninstalled_pkg)>0){
			  sapply(uninstalled_pkg,function(x){biocLite(pkgs = x)})
			}
			sapply(pkg_s,function(x){require(x,character.only = T,quietly = T)})
		  }
	  # Install other packages
		forge_libs=c('estimate')
		forge_lib_load=function(pkg_s=forge_libs){
			installed_pkg=rownames(installed.packages())
			uninstalled_pkg=setdiff(pkg_s,installed_pkg)
			if(length(uninstalled_pkg)>0){
			  sapply(uninstalled_pkg,function(x){install.packages(pkgs = x,repos=rforge,dependencies=T)})
			}
			sapply(pkg_s,function(x){require(x,character.only = T,quietly = T)})
		  }
		  
		# Export list of libaries that are failed to be installed.
		lib_load()
		bio_lib_load()
		forge_libs()
		tmp=sessionInfo()
		unloaded_library<-setdiff(c(necessary_pkg,bio_libs,forge_libs),names(tmp$otherPkgs))
		if(length(unloaded_library)!=0){
			unloaded_library<<-unloaded_library
		}
		un_installed<-setdiff(c(necessary_pkg,bio_libs,forge_libs),rownames(installed.packages()))
		if(length(un_installed)!=0){
			messg=paste0('Failed installation list :',un_installed)
			message(messg)
			un_installed<<-un_installed
		}
    }
	##'mgcv','mvtnorm','cgdsr','gplots','rlang','httpuv','Rcpp','blob','bit','bindr','broom','ggpubr','cmprsk','openxlsx','zoo','RMySQL','survMisc','rio','Matrix','carData','abind','multcomp','rngtools'