#' KS plot
#' 
#' This function is to draw KS plot for two groups
#' @param input_list (default=NULL) : Input list, format like this\cr
#' list('GPC1'=c(1,2,3,4),'GPC2'=c(2,3,4,5))
#' @param color (default=c('black','red')) : Color for groups
#' @param xlab (default=NULL) : label for x-axis
#' @param title (default=NULL) : Title for ks-plot
#' @param lwd (default=1) : Line width
#' @param lty (default=1) : Line style
#' @param cex.main (default=1) : size of title
#' @param cex.axis (default=1) : size of axis
#' @param cex.lab (default=1) : size of label
#' @param legend.param (default=NULL) : Parameter list for legend\cr
#' (ex. list(position='topright',legend=c('GPC1','GPC2'),lty=c(1,2),lwd=5,col=c(1,2),ncol=1))
#' @keywords ks-test, ks plot
#' @export
#' @examples
#' input_list=list('GPC1'=rnorm(10,10),'GPC2'=rnorm(5,5))
#' ks.Plot(input_list=input_list,color=c('blue','red'),
#' legend.param=list(position='topright',legend=c('GPC1','GPC2'),lty=c(1,2),lwd=5,col=c('blue','red'),ncol=1))

  #-----------------------------------------
  # Calculate U score
  #-----------------------------------------
    ks.Plot=function(input_list=NULL,color=c('black','red'),xlab=NULL,title=NULL,
                     lwd=1,lty=1,cex.main=1,cex.axis=1,cex.lab=1,
                     legend.param=NULL){
      if(length(lwd)==1){lwd=rep(lwd,2)}
      if(length(lty)==1){lty=rep(lty,2)}
      # Draw KS plot
        x_range=range(input_list)
        plot(ecdf(input_list[[1]]),verticals=T,do.point=F,col=color[1],xlim=x_range,lwd=lwd[1],lty=lty[1],
             main=title,cex.main=cex.main,cex.axis=cex.axis,cex.lab=cex.lab,xlab=xlab)
        plot(ecdf(input_list[[2]]),verticals=T,do.point=F,col=color[2],add=T,lwd=lwd[2],lty=lty[2])
      # Legend
        if(!is.null(legend.param)){
        legend(legend.param$position,legend = legend.param$legend,col = legend.param$col,ncol = legend.param$ncol,
               lty=legend.param$lty,lwd=legend.param$lwd,)
        }
      # Calculate KS-test p.value
        pv=format(ks.test(input_list[[1]],input_list[[2]])$p.value,nsmall=3,digits=1,scientific=F)
        if(nchar(pv)>8){pv=format(ks.test(input_list[[1]],input_list[[2]])$p.value,nsmall=3,digits=1,scientific=T)}
        mtext(side=3,adj=1,text=paste0('KS-test p=',pv))
    }
    