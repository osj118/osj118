#' scatterPlot_with_Cor.test
#' 
#' This function is to draw and perform correlation test
#' Input vector should be presorted.
#' @param x(default=NULL) : Input vector for x-axis
#' @param y(default=NULL) : Input vector for y-axis
#' @param xlab(default=NULL) : Label of x-axis
#' @param ylab(default=NULL) : Label of y-axis
#' @param title(default=NULL) : title
#' @param cex.lab(default=1) : Size of label
#' @param cex.axis(default=1) : Size of axis
#' @param cex.main(default=1) : Size of title
#' @param cor.method(default='spear') : Correlation test method('pearson','spear')
#' @param pch(default=19) : Point style can be vector
#' @param cex(default=1) : Point size can be vector
#' @param col(default='black') : Point color can be vector
#' @param legend.param : legend parameter list\cr
#' its structure is list(poistion='topright',fill=NULL,pch=NULL,legend = NULL,ncol=NULL)
#' @keywords cor.test, plot
#' @export
#' @examples
#' x=rnorm(10);y=rnorm(10)
#' scatterPlot(x=x,y=y,xlab='x-axis',ylab='y-axis',pch=19)
#' scatterPlot(x=x,y=y,xlab='x-axis',ylab='y-axis',pch=c(1:10))
#' scatterPlot(x=x,y=y,xlab='x-axis',ylab='y-axis',pch=c(1:10),title='hi',
#' legend.param=list(position='topright',fill=c('red','blue'),pch=c(1,2),legend=c('hello','hi'),ncol=1))
    scatterPlot=function(x=NULL,y=NULL,xlab=NULL,ylab=NULL,title=NULL,
                         cex.lab=1,cex.axis=1,cex.main=1,
                         pch=19,cex=1,col='black',cor.method='spear',
                         legend.param=list(poistion='topright',fill=NULL,pch=NULL,legend = NULL,ncol=1)){
      # Drawing part
        plot(x,y,xlab=xlab,ylab=ylab,main=title,pch=pch,cex=cex,cex.lab=cex.lab,cex.axis=cex.axis,cex.main=cex.main)
        abline(lm(y~x),col='red',lty=2,lwd=5)
      # Calculate correlation coefficient and p.value
        pv=cor.test(x,y,method=cor.method)
        rho=format(c(pv$estimate,pv$p.value),nsmall=3,digits=1)
        cor.m=toupper(cor.method)
        mtext(side=3,adj=1,paste0(cor.m,' cor=',rho[1],' ',cor.m,' p.value=',rho[2]))
      # Add legend
        if(!is.null(legend.param$legend)){
          legend(x=legend.param$position,col = legend.param$fill,legend = legend.param$legend,ncol = legend.param$ncol,
                 pch = legend.param$pch)
        }
        return(list('Cor'=rho[1],'P.value'=rho[2],'Test.method'=cor.method))
    }
    