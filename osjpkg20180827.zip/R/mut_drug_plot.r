#' Visualize drug and mutation heatmap
#' 
#' This function is to draw mutation and drug's heatmap
#' @param mat (default=NA) : Input matrix, 1st row drug response, 2nd~ rows mutation (1='Mut',0='WT')
#' @param title (default=NA) : title of plot
#' @param mut_cols (default : c('WT'='white','MUT'='black')) : color of mutation and wild-type
#' @keywords drug, mutation, heatmap, scanning ks-test
#' @export
#' @examples
#' u_val=calc_u(mm='your_matrix') # Get real u value
#' scanning_ks_test(u_real=u_val,iter=500)
#' mut_drug_cor()

  #-----------------------------------------
  # Calculate U score
  #-----------------------------------------
    mut_drug_plot=function(mat,title,mut_cols=c('WT'='grey','MUT'='black'),
                           drug_cols=colorRampPalette(c('blue','white','red'))(50)){
      # mat 2xn_samples, 1st='drug response', 2nd='mutation (binary)'
      # Sort the matrix according drug response
      mat=as.data.frame(mat[,order(mat[1,],decreasing = F)],stringsAsFactors=F)
      # Draw heatmap
        # Setting the layout matrix
          lay_mat=matrix(1:(2*nrow(mat)),byrow = T,ncol=2)
          lay_mat=cbind(0,lay_mat)
          lay_mat=rbind(max(lay_mat)+1,lay_mat)
          lay_mat=rbind(lay_mat,0)
          lay_mat=cbind(lay_mat,c(max(lay_mat),max(lay_mat)+1,rep(0,nrow(lay_mat)-2)))
          lay_mat=cbind(lay_mat,0)
          layout(lay_mat,widths = c(0.5,4,1,1,0.5))
        # Colors
          dry=mat[1,];mutx=mat[-1,]
          par(mar=c(0,0,0,0))
          image(t(as.matrix(dry)),axes=F,col=drug_cols)
          gplots::textplot(rownames(dry),cex = 2,'left')
          for(i in 1:nrow(mutx)){
            image(t(mutx[i,]),col=mut_cols,axes=F)
            gplots::textplot(rownames(mutx)[i],cex=2,'left')
          }
          gplots::textplot(title,cex=6) # title
          # Legend
          par(mar=c(6,0,1,0))
          y_rng=range(dry)
          y_cols=seq(from=y_rng[1],to=y_rng[2],length.out = 100)
          image(as.matrix(y_cols),axes=F,col=drug_cols,ylim=c(0,1),xlim=c(0,1))
          axis(side=1,at=quantile(c(0,1)),las=2,labels = as.numeric(round(quantile(y_rng),2)))
    }
    